<?php
include('../kkksession.php');
if(!session_id())
{
  session_start();
}

if(isset($_SESSION['u_id']) != session_id())
{
  header('Location:../login.php'); 
}
if ($_SESSION['u_type'] != 2) {
  header('Location: ../login.php');
  exit();
}

include '../headermember.php';
include '../db_connect.php';
$memberNo = $_SESSION['funame'];

// Check if the 'status' parameter is present in the URL
  if (isset($_GET['status']) && $_GET['status'] == 'success') {
   echo '<script>
           Swal.fire({
              title: "Berjaya!",
               text: "Maklumat anda telah berjaya disimpan!",
              icon: "success",
               confirmButtonText: "OK"
          });
        </script>';
}

// Loan
// Loan
if (isset($_SESSION['loanApplicationID'])) {
  $loanApplicationID = $_SESSION['loanApplicationID'];
} elseif (isset($_GET['loan_id'])) {
  $loanApplicationID = $_GET['loan_id'];
} else {
  die("Error: Loan application ID is missing.");
}

// Fetch guarantor data from the database
if (isset($loanApplicationID)) {
    $sql = "SELECT g_guarantorID, g_memberNo, g_signature, m.m_name, m.m_ic, m.m_pfNo 
            FROM tb_guarantor g 
            LEFT JOIN tb_member m ON g.g_memberNo = m.m_memberNo 
            WHERE g.g_loanApplicationID = ?";
    
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, "s", $loanApplicationID);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    // Initialize guarantor variables
    $guarantorID1 = null;
    $guarantorID2 = null;
    $anggotaPenjamin1 = 'N/A';
    $signaturePenjamin1 = '';
    $namaPenjamin1 = '';
    $icPenjamin1 = '';
    $pfPenjamin1 = '';
    
    $anggotaPenjamin2 = 'N/A';
    $signaturePenjamin2 = '';
    $namaPenjamin2 = '';
    $icPenjamin2 = '';
    $pfPenjamin2 = '';

    // Fetch the first two guarantors
    if ($row = mysqli_fetch_assoc($result)) {
        $guarantorID1 = $row['g_guarantorID'];
        $anggotaPenjamin1 = $row['g_memberNo'];
        $signaturePenjamin1 = $row['g_signature'];
        $namaPenjamin1 = $row['m_name'];
        $icPenjamin1 = $row['m_ic'];
        $pfPenjamin1 = $row['m_pfNo'];
    }
    
    if ($row = mysqli_fetch_assoc($result)) {
        $guarantorID2 = $row['g_guarantorID'];
        $anggotaPenjamin2 = $row['g_memberNo'];
        $signaturePenjamin2 = $row['g_signature'];
        $namaPenjamin2 = $row['m_name'];
        $icPenjamin2 = $row['m_ic'];
        $pfPenjamin2 = $row['m_pfNo'];
    }

    mysqli_stmt_close($stmt);
}

// Loan details
$selected_jenis_pembiayaan_ID = '';
$selected_jenis_pembiayaan = '';
$selected_amaunDipohon = '';
$selected_tempohPembiayaan = '';
$selected_ansuranBulanan = '';
$selected_namaBank_ID = '';
$selected_namaBank = '';
$selected_bankAcc = '';
$selected_gajiKasar = '';
$selected_gajiBersih = '';
$selected_signature = '';
$selected_pengesahanMajikan = '';
// Fetch data
$sql = "SELECT l_loanType, l_appliedLoan, l_loanPeriod, l_monthlyInstalment, l_bankAccountNo, l_bankName, l_monthlyGrossSalary, l_monthlyNetSalary, l_signature, l_file
FROM tb_loan WHERE l_loanApplicationID = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("i", $loanApplicationID);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
  $selected_jenis_pembiayaan_ID = htmlspecialchars($row['l_loanType']);  
  $selected_amaunDipohon = htmlspecialchars($row['l_appliedLoan']);  
  $selected_tempohPembiayaan = htmlspecialchars($row['l_loanPeriod']);  
  $selected_ansuranBulanan = htmlspecialchars($row['l_monthlyInstalment']);  
  $selected_namaBank_ID = htmlspecialchars($row['l_bankName']);  
  $selected_bankAcc = htmlspecialchars($row['l_bankAccountNo']);  
  $selected_gajiKasar = htmlspecialchars($row['l_monthlyGrossSalary']); 
  $selected_gajiBersih = htmlspecialchars($row['l_monthlyNetSalary']);
  $selected_signature = htmlspecialchars($row['l_signature']);  
  $selected_pengesahanMajikan = htmlspecialchars($row['l_file']);
}

// Fetch the description if an ID is selected
// loan id
if ($selected_jenis_pembiayaan_ID) {
    $sql = "SELECT lt_desc FROM tb_ltype WHERE lt_lid = $selected_jenis_pembiayaan_ID";
    $result = mysqli_query($con, $sql);
    if ($row = mysqli_fetch_assoc($result)) {
        $selected_jenis_pembiayaan = $row['lt_desc'];
    }
}

if ($selected_namaBank_ID) {
    $sql = "SELECT lb_desc FROM tb_lbank WHERE lb_id = $selected_namaBank_ID";
    $result = mysqli_query($con, $sql);
    if ($row = mysqli_fetch_assoc($result)) {
        $selected_namaBank = $row['lb_desc'];
    }
}

// personal id
//Extract from database
$memberNo = isset($_SESSION['funame']) ? $_SESSION['funame'] : null;

// Member personal data
$memberName = '';
$memberIC = '';
$memberEmail = '';
$memberGender_ID = '';
$memberGender = null;
$memberRace_ID = '';
$memberRace = null;
$memberReligion_ID = '';
$memberReligion = null;
$memberMaritalStatus_ID = '';
$memberMaritalStatus = null;
$memberpfNo = '';
$memberMonthlySalary = '';
// Alamat Rumah
$memberHomeAdd = '';
$memberHomePostcode = '';
$memberHomeCity = '';
$memberHomeState_ID = '';
$memberHomeState = '';
// Jawatan
$memberPositionGrade = '';
$memberPosition = '';
// Alamat Pejabat
$memberOfficeAdd = '';
$memberOfficePostcode = '';
$memberOfficeCity = '';
$memberOfficeState_ID = '';
$memberOfficeState = '';
// Telephone
$memberHomeTele = '';
$memberPhoneTele = '';


// Fetch data
if ($memberNo !== null) {
  $sql = "SELECT m_name, m_ic, m_email, m_gender, m_religion, m_race, m_maritalStatus, m_pfNo,
                   m_monthlySalary, m_homeAddress, m_homePostcode, m_homeCity, m_homeState,
                   m_positionGrade, m_position, m_officeAddress, m_officePostcode,
                   m_officeCity, m_officeState, m_homeNumber, m_phoneNumber FROM tb_member WHERE m_memberNo = '$memberNo'";
  $result = mysqli_query($con, $sql);

  if ($row = mysqli_fetch_assoc($result)) {
    $memberName = htmlspecialchars($row['m_name']); 
    $memberIC = htmlspecialchars($row['m_ic']);
    $memberEmail = htmlspecialchars($row['m_email']);
    $memberGender_ID = $row['m_gender'];
    $memberReligion_ID = ($row['m_religion']); 
    $memberRace_ID = ($row['m_race']); 
    $memberMaritalStatus_ID = ($row['m_maritalStatus']);
    $memberpfNo = htmlspecialchars($row['m_pfNo']);
    $memberHomeAdd = htmlspecialchars($row['m_homeAddress']);
    $memberHomePostcode = htmlspecialchars($row['m_homePostcode']);
    $memberHomeCity = htmlspecialchars($row['m_homeCity']);
    $memberHomeState_ID = ($row['m_homeState']);
    $memberPositionGrade = htmlspecialchars($row['m_positionGrade']);
    $memberPosition = htmlspecialchars($row['m_position']);
    $memberOfficeAdd = htmlspecialchars($row['m_officeAddress']);
    $memberOfficePostcode = htmlspecialchars($row['m_officePostcode']);
    $memberOfficeCity = htmlspecialchars($row['m_officeCity']);
    $memberOfficeState_ID = ($row['m_officeState']);
    $memberHomeTele = htmlspecialchars($row['m_homeNumber']);
    $memberPhoneTele = htmlspecialchars($row['m_phoneNumber']);
    $memberMonthlySalary = htmlspecialchars($row['m_monthlySalary']);

  }
}

if ($memberGender_ID) {
    $sql = "SELECT ug_desc FROM tb_ugender WHERE ug_gid = $memberGender_ID";
    $result = mysqli_query($con, $sql);
    if ($row = mysqli_fetch_assoc($result)) {
        $memberGender = $row['ug_desc'];
    }
}

if ($memberReligion_ID) {
  $sql = "SELECT ua_desc FROM tb_ureligion WHERE ua_rid = $memberReligion_ID";
  $result = mysqli_query($con, $sql);
  if ($row = mysqli_fetch_assoc($result)) {
      $memberReligion = $row['ua_desc'];
  }
}

if ($memberRace_ID) {
  $sql = "SELECT ur_desc FROM tb_urace WHERE ur_rid = $memberRace_ID";
  $result = mysqli_query($con, $sql);
  if ($row = mysqli_fetch_assoc($result)) {
      $memberRace = $row['ur_desc'];
  }
}

if ($memberMaritalStatus_ID) {
  $sql = "SELECT um_desc FROM tb_umaritalstatus WHERE um_mid = $memberMaritalStatus_ID";
  $result = mysqli_query($con, $sql);
  if ($row = mysqli_fetch_assoc($result)) {
      $memberMaritalStatus = $row['um_desc'];
  }
}

if ($memberHomeState_ID) {
  $sql = "SELECT st_desc FROM tb_homestate WHERE st_id = $memberHomeState_ID";
  $result = mysqli_query($con, $sql);
  if ($row = mysqli_fetch_assoc($result)) {
      $memberHomeState = $row['st_desc'];
  }
}

if ($memberOfficeState_ID) {
  $sql = "SELECT st_desc FROM tb_homestate WHERE st_id = $memberOfficeState_ID";
  $result = mysqli_query($con, $sql);
  if ($row = mysqli_fetch_assoc($result)) {
      $memberOfficeState = $row['st_desc'];
  }
}

// Guarantor details
$anggotaPenjamin1 = '';
$namaPenjamin1 = '';
$icPenjamin1 = '';
$pfPenjamin1 = '';
$signaturePenjamin1 = '';
$anggotaPenjamin2 = '';
$namaPenjamin2 = '';
$icPenjamin2 = '';
$pfPenjamin2 = '';
$signaturePenjamin2 = '';

// Fetch data for guarantor 1
if ($guarantorID1 !== null) {
    $sql = "SELECT g.g_memberNo, g.g_signature, m.m_name, m.m_ic, m.m_pfNo 
            FROM tb_guarantor g
            LEFT JOIN tb_member m ON g.g_memberNo = m.m_memberNo 
            WHERE g.g_guarantorID = '$guarantorID1'";
    $result = mysqli_query($con, $sql);

    if ($result && $row = mysqli_fetch_assoc($result)) {
        $anggotaPenjamin1 = $row['g_memberNo'];
        $signaturePenjamin1 = $row['g_signature'];
        $namaPenjamin1 = $row['m_name'];
        $icPenjamin1 = $row['m_ic'];
        $pfPenjamin1 = $row['m_pfNo'];
    }
} else {
    $anggotaPenjamin1 = 'N/A';
    $signaturePenjamin1 = 'N/A';
    $namaPenjamin1 = 'N/A';
    $icPenjamin1 = 'N/A';
    $pfPenjamin1 = 'N/A';
}

// Fetch data for guarantor 2
if ($guarantorID2 !== null) {
    $sql2 = "SELECT g.g_memberNo, g.g_signature, m.m_name, m.m_ic, m.m_pfNo 
             FROM tb_guarantor g
             LEFT JOIN tb_member m ON g.g_memberNo = m.m_memberNo 
             WHERE g.g_guarantorID = '$guarantorID2'";
    $result2 = mysqli_query($con, $sql2);

    if ($result2 && $row2 = mysqli_fetch_assoc($result2)) {
        $anggotaPenjamin2 = $row2['g_memberNo'];
        $signaturePenjamin2 = $row2['g_signature'];
        $namaPenjamin2 = $row2['m_name'];
        $icPenjamin2 = $row2['m_ic'];
        $pfPenjamin2 = $row2['m_pfNo'];
    }
} else {
    $anggotaPenjamin2 = 'N/A';
    $signaturePenjamin2 = 'N/A';
    $namaPenjamin2 = 'N/A';
    $icPenjamin2 = 'N/A';
    $pfPenjamin2 = 'N/A';
}

error_log("Debug - Guarantor 1 ID: " . $guarantorID1);
error_log("Debug - Guarantor 1 Member No: " . $anggotaPenjamin1);
error_log("Debug - Guarantor 1 Name: " . $namaPenjamin1);
error_log("Debug - Guarantor 2 ID: " . $guarantorID2);
error_log("Debug - Guarantor 2 Member No: " . $anggotaPenjamin2);
error_log("Debug - Guarantor 2 Name: " . $namaPenjamin2);
?>

<form method = "post" action = "semakan_butiran_process.php">
  <fieldset>
    <!--Semakan Butiran-->
    <div class="container">
      <br>
      <div class="jumbotron">
          <h2>Semakan Butiran</h2>
          <div class="card mb-3">
            <div class="card-header text-white bg-primary d-flex justify-content-between align-items-center">
                Butir-butir Pembiayaan
                <button type="button" class="btn btn-info"  onclick="window.location.href='semakan_pinjaman.php?loan_id=<?php echo $loanApplicationID; ?>'">
                    Kemaskini
                </button>
            </div>
            <div class="card-body">

                <table class="table table-hover">
                <tbody>
                    <tr>
                    <td scope="row">Jenis Pembiayaan</td>
                    <td><?php echo $selected_jenis_pembiayaan; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Amoun Dipohon</td>
                    <td><?php echo "RM ", $selected_amaunDipohon; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Tempoh Pembiayaan</td>
                    <td><?php echo $selected_tempohPembiayaan, " tahun"; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Ansuran Bulanan</td>
                    <td><?php echo "RM ", $selected_ansuranBulanan; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Nama Bank/Cawangan</td>
                    <td><?php echo $selected_namaBank; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Bank Account</td>
                    <td><?php echo $selected_bankAcc; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Gaji Kasar Bulanan</td>
                    <td><?php echo "RM ", $selected_gajiKasar; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Gaji Bersih Bulanan</td>
                    <td><?php echo "RM ", $selected_gajiBersih; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Tandatangan</td>
                    <td>
                    <?php if (!empty($selected_signature) && $selected_signature !== '') : ?>
                        <img src="./uploads/<?php echo $selected_signature; ?>" alt="Signature" style="max-width: 200px; height: auto;">
                    <?php  else : ?>
                        <span>N/A</span>
                    <?php endif; ?>
                      </td>
                    </tr>
                </tbody>
                </table>
            
            </div>

    </div>

    </hr>
      <hr class="my-4">
        <p class="lead">
        </p>
      </hr>


        <div class="card mb-3">
            <div class="card-header text-white bg-primary d-flex justify-content-between align-items-center">
                Butir-butir Peribadi Pemohon
                <button type="button" class="btn btn-info"  onclick="window.location.href='semakan_butir_peribadi.php?loan_id=<?php echo $loanApplicationID; ?>'">
                    Kemaskini
                </button>
            </div>
            <div class="card-body">

                <table class="table table-hover">
                <tbody>
                    <tr>
                    <td scope="row">Nama</td>
                    <td><?php echo $memberName; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">No. Kad Pengenalan</td>
                    <td><?php echo $memberIC; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Email</td>
                    <td><?php echo $memberEmail; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Jantina</td>
                    <td><?php echo $memberGender; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Agama</td>
                    <td><?php echo $memberReligion; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Bangsa</td>
                    <td><?php echo $memberRace; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Taraf Perkahwinan</td>
                    <td><?php echo $memberMaritalStatus; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">No. Anggota</td>
                    <td><?php echo $memberNo; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">No. PF</td>
                    <td><?php echo $memberpfNo; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Alamat Rumah</td>
                    <td><?php echo $memberHomeAdd; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Poskod</td>
                    <td><?php echo $memberHomePostcode; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Bandar</td>
                    <td><?php echo $memberHomeCity; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Negeri</td>
                    <td><?php echo $memberHomeState; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Jawatan Gred</td>
                    <td><?php echo $memberPositionGrade; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Jawatan</td>
                    <td><?php echo $memberPosition; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Alamat Pejabat (Tempat Bertugas)</td>
                    <td><?php echo $memberOfficeAdd; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Poskod</td>
                    <td><?php echo $memberOfficePostcode; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Bandar</td>
                    <td><?php echo $memberOfficeCity; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">No. Telefon Rumah</td>
                    <td><?php echo $memberHomeTele; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">No. Telefon Bimbit</td>
                    <td><?php echo $memberPhoneTele; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Gaji Bulanan</td>
                    <td><?php echo "RM ", $memberMonthlySalary; ?></td>
                    </tr>


                </tbody>
                </table>
            
            </div>

    </div>
      <hr class="my-4">
        <p class="lead"></p>
      </hr>
    </div>
    
    <div class="card mb-3">
            <div class="card-header text-white bg-primary d-flex justify-content-between align-items-center">
                Butir-butir Penjamin
                <button type="button" class="btn btn-info"  onclick="window.location.href='semakan_penjamin.php?loan_id=<?php echo $loanApplicationID; ?>'">
                    Kemaskini
                </button>
            </div>
            <div class="card-body">

                <table class="table table-hover">
                <tbody>
                    <!-- Penjamin 1-->
                    <tr>
                    <td scope="row">Penjamin 1</td>
                    <td></td>
                    </tr>

                    <tr>
                    <td scope="row">No. Anggota</td>
                    <td><?php echo $anggotaPenjamin1; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Nama</td>
                    <td><?php echo $namaPenjamin1; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">No. Kad Pengenalan</td>
                    <td><?php echo $icPenjamin1; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">No. PF</td>
                    <td><?php echo $pfPenjamin1; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Tandatangan</td>
                    <td>
                    <?php if (!empty($signaturePenjamin1) && $signaturePenjamin1 !== 'N/A') : ?>
                        <img src="./uploads/<?php echo $signaturePenjamin1; ?>" alt="Signature" style="max-width: 200px; height: auto;">
                    <?php else : ?>
                        <span>N/A</span>
                    <?php endif; ?>
                    </td>
                    </tr>

                    <!-- Penjamin 2-->
                    <tr>
                    <td scope="row">Penjamin 2</td>
                    <td></td>
                    </tr>

                    <tr>
                    <td scope="row">No. Anggota</td>
                    <td><?php echo $anggotaPenjamin2; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Nama</td>
                    <td><?php echo $namaPenjamin2; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">No. Kad Pengenalan</td>
                    <td><?php echo $icPenjamin2; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">No. PF</td>
                    <td><?php echo $pfPenjamin2; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Tandatangan</td>
                    <td>
                    <?php if (!empty($signaturePenjamin2) && $signaturePenjamin2 !== 'N/A') : ?>
                        <img src="./uploads/<?php echo $signaturePenjamin2; ?>" alt="Signature" style="max-width: 200px; height: auto;">
                    <?php else : ?>
                        <span>N/A</span>
                    <?php endif; ?>
                    </td>
                    </tr>

                </tbody>
                </table>
            </div>
    </div>
    <hr class="my-4">
      <p class="lead"></p>
    </hr>
    <div class="card mb-3">
              <div class="card-header text-white bg-primary d-flex justify-content-between align-items-center">
                  Pengesahan Majikan
                  <button type="button" class="btn btn-info"  onclick="window.location.href='semakan_pengesahan_majikan.php?loan_id=<?php echo $loanApplicationID; ?>'">
                      Kemaskini
                  </button>
              </div>

            <div class="card-body">

                <table class="table table-hover">
                <tbody>
                    <tr>
                    <td scope="row">Gaji Pokok Bulanan</td>
                    <td><?php echo "RM ", $selected_gajiKasar; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Gaji Bersih Bulanan</td>
                    <td><?php echo "RM ", $selected_gajiBersih; ?></td>
                    </tr>

                    <tr>
                    <td scope="row">Pengesahan Majikan</td>
                    <td>
                        <?php
                        $file_path = $_SERVER['DOCUMENT_ROOT'] . '/KKK-System/loan_application/uploads/' . basename($selected_pengesahanMajikan);
                        $pdf_url = 'http://' . $_SERVER['HTTP_HOST'] . '/KKK-System/loan_application/uploads/' . basename($selected_pengesahanMajikan);

                        if (!empty($selected_pengesahanMajikan) && file_exists($file_path)) : ?>
                            <a href="<?php echo $pdf_url; ?>" class="btn btn-primary" target="_blank">
                                <i class="fas fa-external-link"></i> Lihat
                            </a>
                        <?php else : ?>
                            <span>Tiada dokumen PDF.</span>
                        <?php endif; ?>
                    </td>
                  </tr>
                </tbody>
                </table>
            
            </div>
    </div>
    
    <link href="bootstrap.css" rel="stylesheet">

    <div style="text-align: center;">
      <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#confirmationModal">Simpan</button>
    </div>

<!-- Modal -->
<div class="modal fade" id="confirmationModal" tabindex="-1" role="dialog" aria-labelledby="confirmationModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="confirmationModalLabel">Sahkan Tindakan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Adakah anda ingin meneruskan tindakan HANTAR?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" class="btn btn-primary" onclick="submitForm()">Ya, Hantar</button>
      </div>
    </div>
  </div>
</div>

  </fieldset>
</form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script> <!-- Bootstrap JS -->

<script>
  // Function to handle the form submission after confirmation
  function submitForm() {
    // Update status to 1 before submitting the form
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "semakan_butiran_process.php", true); // Ensure you have a file to handle this
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.send("status=1"); // Send the status update

    // Submit the form after updating the status
    document.forms[0].submit(); // Submit the form (change index if necessary)
  }
</script>

</body>
</html>

<?php include '../footer.php'; ?>