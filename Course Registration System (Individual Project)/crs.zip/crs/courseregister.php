<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}

if ($_SESSION['u_type']!=2) { 
    header('Location:login.php');
    exit();
}

include('headerstudent.php');
include('dbconnect.php');

$search_code = isset($_GET['search_code']) ? $_GET['search_code'] : '';
?>

<div class="container">
  <br><br><h5 style="text-align: center;">Course Registration Form</h5>
  <br>
  
  <form method="GET" class="form-inline">
      <label for="search_code">Search Course Code:</label>
      <input type="text" name="search_code" id="search_code" class="form-control" value="<?php echo $search_code; ?>" placeholder="Enter course code">
      <br>
      <div class="d-flex justify-content-center mt-3">
        <button type="submit" class="btn btn-primary">Search</button>
      </div>
  </form>

  <?php 
    if (!empty($search_code)){ 
  ?>
  <form method="POST" action="courseregisterprocess.php">
  <fieldset>

    <div>
      <label for="exampleSelect1" class="form-label mt-4">Select Course</label>
      <select class="form-select" name="fcourse" id="courseSelect" required>
        <?php
          $sql="SELECT c_code, c_name, c_section, c_sem 
                FROM tb_course 
                WHERE c_code LIKE '%$search_code%'";
          $result=mysqli_query($con, $sql);
          
          if (mysqli_num_rows($result)>0){
              while ($row=mysqli_fetch_array($result)){
                  $courseInfo=$row['c_name'] . " (Section: " . $row['c_section'] . ") (Semester: " . $row['c_sem'] . ")";
                  echo "<option value='" . $row['c_code'] . "' data-section='" . $row['c_section'] . "' data-semester='" . $row['c_sem'] . "'>" . $courseInfo . "</option>";
              }
          } 
          else{
              echo "<option value=''>No courses found</option>";
          }
        ?>
      </select>
    </div>

    <input type="hidden" name="fsection" id="hiddenSection" value="">
    <input type="hidden" name="fsem" id="hiddenSemester" value="">

    <br>
    <div class="d-flex justify-content-center">
      <button type="submit" class="btn btn-success">Register</button>
    </div>
  </fieldset>
  </form>
  <?php } ?>

  <br><br><br>
</div>

<script>
  const courseSelect=document.getElementById('courseSelect');
  const hiddenSection=document.getElementById('hiddenSection');
  const hiddenSemester=document.getElementById('hiddenSemester');

  courseSelect.addEventListener('change', function () {
    const selectedOption=courseSelect.options[courseSelect.selectedIndex];
    hiddenSection.value=selectedOption.getAttribute('data-section');
    hiddenSemester.value=selectedOption.getAttribute('data-semester');
  });

  courseSelect.dispatchEvent(new Event('change'));
</script>

<?php include 'footer.php';?>
