<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}

if ($_SESSION['u_type']!=1) {
    header('Location:login.php');
    exit();
}

include 'headerlect.php';
include 'dbconnect.php';

if (isset($_GET['c_id']) && is_numeric($_GET['c_id'])) {
    $c_id=intval($_GET['c_id']);

    $course_sql="SELECT * FROM tb_course 
                   WHERE c_id = $c_id";
    $course_result=mysqli_query($con, $course_sql);

    if (mysqli_num_rows($course_result)>0){
        $course=mysqli_fetch_assoc($course_result);

        $student_sql="SELECT tb_registration.r_student, tb_user.u_name, tb_user.u_email
                      FROM tb_registration
                      INNER JOIN tb_user ON tb_registration.r_student=tb_user.u_sno
                       WHERE tb_registration.r_course='{$course['c_code']}'
                      AND tb_registration.r_sem='{$course['c_sem']}'
                      AND tb_registration.r_status=2";

        $student_result=mysqli_query($con, $student_sql);
    } 
    else{
        die("<div class='container'><h4 style='text-align: center;'>Invalid course ID.</h4></div>");
    }
} 
else{
    die("<div class='container'><h4 style='text-align: center;'>Course ID not specified or invalid.</h4></div>");
}
?>

<style>
  table thead th{
    text-align: center;
    background-color: #f1f1f1;
  }

  table tbody td{
    text-align: center;
  }
  
</style>

<div class="container mt-4">
    <h1 class="text-center"><b>Student List</b></h1>
    <br>
    <h6 class="text-center">Code: <?= $course['c_code']; ?></h6>
    <h6 class="text-center">Name: <?= $course['c_name']; ?></h6>
    <h6 class="text-center">Section: <?= $course['c_section']; ?></h6>
    <h6 class="text-center">Semester: <?= $course['c_sem']; ?></h6>
    <br>
    <table class="table table-hover mt-3">
        <thead class="thead-light">
            <tr>
                <th scope="col">No</th>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">View Details</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (mysqli_num_rows($student_result)>0) {
                $count=1;
                while ($row = mysqli_fetch_assoc($student_result)) {
                    echo "<tr>";
                    echo "<td>" . $count . "</td>";
                    echo "<td>" . $row['r_student'] . "</td>";
                    echo "<td>" . $row['u_name'] . "</td>";
                    echo "<td>" . $row['u_email'] . "</td>";
                    echo "<td>" . "<a href='studentdetail.php?r_student=" . $row['r_student'] . "&c_id=" . $c_id . "'><button type='submit' class='btn btn-info'>Details</button></a>";

                    echo "</tr>";
                    $count++;
                }
            } else {
                echo "<tr><td colspan='3' class='text-center'>No students found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
    <br>
    <div class="d-flex justify-content-center">
        <button type="button" class="btn btn-secondary" onclick="window.location.href='lectcourselist.php'">Back</button>
    </div>
</div>

<?php include 'footer.php'; ?>
