<?php
include('crssession.php');
if(!session_id())
{
  session_start();
}

if ($_SESSION['u_type']!=2) { 
    header('Location:login.php');
    exit();
}

include 'headerstudent.php';
include 'dbconnect.php';
$uic=$_SESSION['funame'];

$sql="SELECT DISTINCT tb_registration.r_tid,tb_registration.*,
      tb_course.c_name,
      tb_status.*
      FROM tb_registration
      LEFT JOIN tb_course ON tb_registration.r_course=tb_course.c_code
      LEFT JOIN tb_status ON tb_registration.r_status=tb_status.s_id
      WHERE r_student='$uic'";

$result=mysqli_query($con,$sql);

if (isset($_GET['delete_id'])){
    $delete_id=$_GET['delete_id'];
    $delete_query="DELETE FROM tb_registration 
                   WHERE r_tid='$delete_id'";
    mysqli_query($con,$delete_query);
    header('Location: courseview.php');
    exit();
}
?>

<style>
  table thead th{
      text-align: center;
      background-color: #f1f1f1;
  }

  table tbody td{
      text-align: center;
  }
</style>

<div class="container">
  <br><br>
<table class="table table-hover">
  <thead>
    
    <tr>
      <th scope="col">Transaction ID</th>
      <th scope="col">Semester</th>
      <th scope="col">Course</th>
      <th scope="col">Course Name</th>
      <th scope="col">Section</th>
      <th scope="col">Status</th>
      <th scope="col">Operations</th>
    </tr>
  </thead>
  <tbody>

    <?php
    while($row=mysqli_fetch_array($result)){
      echo"<tr>";
      echo"<td>".$row['r_tid']."</td>";
      echo"<td>".$row['r_sem']."</td>";
      echo"<td>".$row['r_course']."</td>";
      echo"<td>".$row['c_name']."</td>";
      echo"<td>".$row['r_section']."</td>";
      echo"<td>".$row['s_decs']."</td>";
      ?>
      <td>
        <button type="button" class="btn btn-warning" onclick="modify_registration(<?php echo $row['r_tid']; ?>, <?php echo $row['r_status']; ?>)">Modify</button>
      </td>
      <td><button type="button" onclick="delete_course(<?php echo $row['r_tid']; ?>)" class="btn btn-danger">Cancel</button></td>

      <?php
        }
      ?>

</table>
<br><br><br><br>

<script>
  function delete_course(delete_id){
    Swal.fire({
      title: 'Are you sure?',
      text: 'This registration will be deleted .',
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.isConfirmed){
        Swal.fire({
          icon: 'success',
          title: 'Registration is deleted!',
          showConfirmButton: true
        }).then(() => {
          window.location.href = `courseview.php?delete_id=${delete_id}`;
        });
      } 
      else {
        Swal.fire({
          icon: 'info',
          title: 'Registration is not deleted!',
        }).then(() => {
          window.location.href='courseview.php';
        });
      }
    });
  }

  function modify_registration(r_tid,r_status) {
    if (r_status!==1){
      Swal.fire({
        icon: 'error',
        title: 'Modification Not Allowed!',
        text: 'You can only modify registrations with "Received" status.',
      });
    } 
    else{
      window.location.href = `studentmodifyregistration.php?r_tid=${r_tid}`;
    }
  }
</script>



  
</div>
<?php include 'footer.php';?>