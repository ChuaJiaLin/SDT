-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 30, 2025 at 08:36 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_crs`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_course`
--

CREATE TABLE `tb_course` (
  `c_id` int(11) NOT NULL,
  `c_code` varchar(10) NOT NULL,
  `c_name` varchar(30) NOT NULL,
  `c_section` int(11) NOT NULL,
  `c_credit` int(11) NOT NULL,
  `c_sem` varchar(12) NOT NULL,
  `c_lec` varchar(10) NOT NULL,
  `c_studNum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_course`
--

INSERT INTO `tb_course` (`c_id`, `c_code`, `c_name`, `c_section`, `c_credit`, `c_sem`, `c_lec`, `c_studNum`) VALUES
(18, 'SECJ2013', 'DATA STRUCTURE AND ALGORITHM', 1, 3, '2024/2025-1', 'L001', 1),
(19, 'SECJ2013', 'DATA STRUCTURE AND ALGORITHM', 2, 3, '2024/2025-1', 'L002', 30),
(20, 'SECJ2013', 'DATA STRUCTURE AND ALGORITHM', 1, 3, '2024/2025-2', 'L003', 30),
(21, 'SECJ2013', 'DATA STRUCTURE AND ALGORITHM', 2, 3, '2024/2025-2', 'L001', 30),
(22, 'SECP2523', 'DATABASE (WBL)', 1, 3, '2024/2025-1', 'L002', 35),
(23, 'SECP2523', 'DATABASE (WBL)', 2, 3, '2024/2025-1', 'L001', 35),
(24, 'SECP2523', 'DATABASE (WBL)', 1, 3, '2024/2025-3', 'L003', 35),
(25, 'SECP2523', 'DATABASE (WBL)', 2, 3, '2024/2025-3', 'L001', 35),
(26, 'SECP3204', 'SOFTWARE ENGINEERING (WBL)', 1, 4, '2024/2025-2', 'L001', 40),
(27, 'SECP3204', 'SOFTWARE ENGINEERING (WBL)', 2, 4, '2024/2025-2', 'L003', 40),
(28, 'SECP3204', 'SOFTWARE ENGINEERING (WBL)', 1, 4, '2024/2025-3', 'L002', 40),
(29, 'SECP3204', 'SOFTWARE ENGINEERING (WBL)', 2, 4, '2024/2025-3', 'L001', 40),
(30, 'SECP3723', 'SYSTEM DEVELOPMENT TECHNOLOGY', 1, 3, '2024/2025-1', 'L001', 50),
(31, 'SECP3723', 'SYSTEM DEVELOPMENT TECHNOLOGY', 1, 3, '2024/2025-3', 'L003', 50),
(32, 'SECR1213', 'NETWORK COMMUNICATIONS', 1, 3, '2024/2025-1', 'L003', 35),
(33, 'SECR1213', 'NETWORK COMMUNICATIONS', 2, 3, '2024/2025-1', 'L001', 35),
(34, 'SECR1213', 'NETWORK COMMUNICATIONS', 1, 3, '2024/2025-2', 'L002', 35);

-- --------------------------------------------------------

--
-- Table structure for table `tb_registration`
--

CREATE TABLE `tb_registration` (
  `r_tid` int(11) NOT NULL COMMENT 'This is the transcation id',
  `r_student` varchar(10) NOT NULL,
  `r_course` varchar(10) NOT NULL,
  `r_sem` varchar(11) NOT NULL,
  `r_section` int(11) NOT NULL,
  `r_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_registration`
--

INSERT INTO `tb_registration` (`r_tid`, `r_student`, `r_course`, `r_sem`, `r_section`, `r_status`) VALUES
(28, 'S005', 'SECJ2013', '2024/2025-1', 1, 2),
(29, 'S005', 'SECP2523', '2024/2025-3', 1, 2),
(30, 'S005', 'SECP3204', '2024/2025-2', 2, 2),
(34, 'S003', 'SECJ2013', '2024/2025-1', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_status`
--

CREATE TABLE `tb_status` (
  `s_id` int(11) NOT NULL,
  `s_decs` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_status`
--

INSERT INTO `tb_status` (`s_id`, `s_decs`) VALUES
(1, 'Received'),
(2, 'Approved'),
(3, 'Rejected'),
(4, 'Amended');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `u_sno` varchar(10) NOT NULL,
  `u_pwd` varchar(255) NOT NULL,
  `u_email` varchar(30) NOT NULL,
  `u_name` varchar(50) NOT NULL,
  `u_contact` int(11) NOT NULL,
  `u_state` varchar(20) NOT NULL,
  `u_registration` timestamp NULL DEFAULT NULL,
  `u_type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`u_sno`, `u_pwd`, `u_email`, `u_name`, `u_contact`, `u_state`, `u_registration`, `u_type`) VALUES
('A001', 'e10adc3949ba59abbe56e057f20f883e', 'kamarul@gmail.com', 'Kamarul bin Hazmi', 126897453, 'Selangor', '2025-01-29 09:18:03', 3),
('L001', 'e10adc3949ba59abbe56e057f20f883e', 'amira@gmail.com', 'Amira bin Farhan', 182221789, 'Negeri Sembilan', '2025-01-29 09:14:29', 1),
('L002', 'e10adc3949ba59abbe56e057f20f883e', 'rizal@gmail.com', 'Rizal bin Hamdan', 182227852, 'Kedah', '2025-01-29 09:15:15', 1),
('L003', 'e10adc3949ba59abbe56e057f20f883e', 'ali@gmail.com', 'Ali bin Abu', 182221234, 'W.P. Kuala Lumpur', '2025-01-29 07:11:31', 1),
('S001', 'e10adc3949ba59abbe56e057f20f883e', 'siti@gmail.com', 'Siti bin Afif', 164896523, 'Kelantan', '2025-01-29 09:16:28', 2),
('S002', 'e10adc3949ba59abbe56e057f20f883e', 'amy@gmail.com', 'Amy Chan', 167986135, 'W.P. Putrajaya', '2025-01-29 09:17:11', 2),
('S003', 'e10adc3949ba59abbe56e057f20f883e', 'abu@gmail.com', 'Abu bin Ali', 182221236, 'Sabah', '2025-01-29 07:05:38', 2),
('S004', 'e10adc3949ba59abbe56e057f20f883e', 'karen@gmail.com', 'Karen Wong', 182035987, 'Sarawak', '2025-01-29 19:59:03', 2),
('S005', 'e10adc3949ba59abbe56e057f20f883e', 'benjamin@gmail.com', 'Benjamin Tan', 182035531, 'Johor', '2025-01-30 05:37:49', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tb_utype`
--

CREATE TABLE `tb_utype` (
  `t_id` int(11) NOT NULL,
  `t_desc` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_utype`
--

INSERT INTO `tb_utype` (`t_id`, `t_desc`) VALUES
(1, 'Lecturer'),
(2, 'Student'),
(3, 'IT Staff');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_course`
--
ALTER TABLE `tb_course`
  ADD PRIMARY KEY (`c_id`),
  ADD KEY `c_lec` (`c_lec`),
  ADD KEY `c_code` (`c_code`),
  ADD KEY `c_section` (`c_section`);

--
-- Indexes for table `tb_registration`
--
ALTER TABLE `tb_registration`
  ADD PRIMARY KEY (`r_tid`),
  ADD KEY `r_student` (`r_student`),
  ADD KEY `r_course` (`r_course`),
  ADD KEY `r_status` (`r_status`),
  ADD KEY `r_section` (`r_section`),
  ADD KEY `r_sem` (`r_sem`);

--
-- Indexes for table `tb_status`
--
ALTER TABLE `tb_status`
  ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`u_sno`),
  ADD KEY `u_type` (`u_type`);

--
-- Indexes for table `tb_utype`
--
ALTER TABLE `tb_utype`
  ADD PRIMARY KEY (`t_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_course`
--
ALTER TABLE `tb_course`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `tb_registration`
--
ALTER TABLE `tb_registration`
  MODIFY `r_tid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'This is the transcation id', AUTO_INCREMENT=35;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_course`
--
ALTER TABLE `tb_course`
  ADD CONSTRAINT `tb_course_ibfk_1` FOREIGN KEY (`c_lec`) REFERENCES `tb_user` (`u_sno`);

--
-- Constraints for table `tb_registration`
--
ALTER TABLE `tb_registration`
  ADD CONSTRAINT `tb_registration_ibfk_1` FOREIGN KEY (`r_student`) REFERENCES `tb_user` (`u_sno`),
  ADD CONSTRAINT `tb_registration_ibfk_3` FOREIGN KEY (`r_status`) REFERENCES `tb_status` (`s_id`),
  ADD CONSTRAINT `tb_registration_ibfk_4` FOREIGN KEY (`r_course`) REFERENCES `tb_course` (`c_code`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD CONSTRAINT `tb_user_ibfk_1` FOREIGN KEY (`u_type`) REFERENCES `tb_utype` (`t_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
