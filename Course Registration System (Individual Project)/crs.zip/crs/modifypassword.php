<?php
session_start();

include('dbconnect.php');
include 'headermain.php';

if ($_SERVER["REQUEST_METHOD"]=="POST"){
    $new_password=$_POST['new_password'];
    $confirm_password=$_POST['confirm_password'];

    if ($new_password!==$confirm_password){
        echo "<script>
                Swal.fire({
                    icon: 'error',
                    title: 'Passwords do not match!',
                    text: 'Please try again.',
                    showConfirmButton: true
                }).then(() => {
                    window.location.href='modifypassword.php';
                });
              </script>";
        exit();
    }

    $hashed_password=md5($new_password);

    $funame=$_SESSION['funame'];

    $sql="UPDATE tb_user 
          SET u_pwd='$hashed_password' 
          WHERE u_sno='$funame'";

    if (mysqli_query($con,$sql)){
        echo "<script>
                Swal.fire({
                    icon: 'success',
                    title: 'Password Updated Successfully!',
                    text: 'Your password has been updated.',
                    showConfirmButton: true
                }).then(() => {
                    window.location.href='login.php'; 
                });
              </script>";
    } else {
        echo "<script>
                Swal.fire({
                    icon: 'error',
                    title: 'Password Update Failed!',
                    text: 'Something went wrong. Please try again.',
                    showConfirmButton: true
                }).then(() => {
                    window.location.href='modifypassword.php';
              </script>";
    }
}

mysqli_close($con);

?>

<div class="container">

  <br><br><h3 style="text-align: center;">Modify Password</h3>
  <form method="POST" action="">
  <fieldset>
 
    <div>
      <label for="exampleInputEmail1" class="form-label mt-4">Enter new password</label>
      <input type="password"  name="new_password" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter new password" autocomplete="off" required>
    </div>

    <div>
      <label for="exampleInputPassword1" class="form-label mt-4">Confirm password</label>
      <input type="password" name="confirm_password" class="form-control" id="exampleInputPassword1" placeholder="Confirm password" autocomplete="off" required>
    </div>

    <br>
    <div class="d-flex justify-content-center">
      <button type="submit" class="btn btn-primary">Modify</button>
    </div>
   </fieldset>

</form>
<br><br><br>
</div>

<?php include 'footer.php';?>