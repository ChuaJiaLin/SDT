<?php
session_start();

//Connect to DB
include('dbconnect.php');
include 'headermain.php';

//Retrieve data from form
$funame = $_POST['funame'];
$fpwd = $_POST['fpwd'];

$hashed_password=md5($fpwd);

//SQL Retrieve operation to get user data from DB
$sql = "SELECT * FROM tb_user
        WHERE u_sno='$funame' AND u_pwd='$hashed_password'";

//Execute SQL
$result=mysqli_query($con, $sql);

//Retrieve data
$row=mysqli_fetch_array($result);

//Count result to check
$count=mysqli_num_rows($result);

//Rule-based AI login
if($count==1)  //check user exist
{
    //Set session
    $_SESSION['u_sno']= session_id();
    $_SESSION['funame']= $funame;
    $_SESSION['u_type'] = $row['u_type'];
    
    echo "<script>
                Swal.fire({
                    icon: 'success',
                    title: 'Login Successful!',
                    text: 'Welcome to the system.',
                    showConfirmButton: true
                });
              </script>";

    if($row['u_type']==1)  //Check user type
    {
        //Lecturer
        echo "<script>
                Swal.fire({
                    icon: 'success',
                    title: 'Login Successful!',
                    text: 'Welcome to the system.',
                    showConfirmButton: true
                }).then(() => {
                    window.location.href='lect.php';
                });
              </script>";
    }
    if($row['u_type']==2)  //Check user type
    {
        //Student
        echo "<script>
                Swal.fire({
                    icon: 'success',
                    title: 'Login Successful!',
                    text: 'Welcome to the system.',
                    showConfirmButton: true
                }).then(() => {
                    window.location.href='student.php';
                });
              </script>";
    } 
    if($row['u_type']==3)  //Check user type
    {
        //IT Staff
        echo "<script>
                Swal.fire({
                    icon: 'success',
                    title: 'Login Successful!',
                    text: 'Welcome to the system.',
                    showConfirmButton: true
                }).then(() => {
                    window.location.href='admindashboard.php';
                    });
              </script>";
    }
}
else  //user not found
{
    //Redirect to login page (individual project)
    echo "<script>
                Swal.fire({
                    icon: 'error',
                    title: 'Login Failed!',
                    text: 'Incorrect ID or password. Please try again.',
                    showConfirmButton: true
                }).then(() => {
                    window.location.href='login.php';
                });
              </script>";
              exit;

}

//Close connection
mysqli_close($con);



?>