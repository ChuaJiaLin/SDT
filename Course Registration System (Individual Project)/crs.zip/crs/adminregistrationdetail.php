<?php
include('crssession.php');
if(!session_id())
{
  session_start();
}

if ($_SESSION['u_type']!=3) { 
    header('Location:login.php');
    exit();
}

include 'headeradmin.php';
include 'dbconnect.php';
$uic=$_SESSION['funame'];

if (isset($_GET['r_tid']) && !empty($_GET['r_tid']) && is_numeric($_GET['r_tid'])){
  $r_tid=intval($_GET['r_tid']);
} 
else{
  die("<div class='container'><h4 style='text-align: center;'>Invalid registration ID.</h4></div>");
}

$sql="SELECT tb_registration.*,
               tb_user.u_name, 
               tb_course.c_name,
               tb_status.s_decs AS status
        FROM tb_registration 
        LEFT JOIN tb_user ON tb_registration.r_student=tb_user.u_sno
        LEFT JOIN tb_course ON tb_registration.r_course=tb_course.c_code
        LEFT JOIN tb_status ON tb_registration.r_status=tb_status.s_id
        WHERE r_tid=$r_tid";

$result=mysqli_query($con,$sql);

if (!$result||mysqli_num_rows($result)==0){
    die("<div class='container'><h4 style='text-align: center;'>No registration details found.</h4></div>");
}

$row=mysqli_fetch_assoc($result);

if ($_SERVER['REQUEST_METHOD'] === 'POST'){
    $new_section=$_POST['r_section'];

    $update_sql = "UPDATE tb_registration 
                   SET r_section='$new_section',
                       r_status='4'
                   WHERE r_tid='$r_tid'";

    if (!mysqli_query($con,$update_sql)){
        die("Error: " . mysqli_error($con));
    } 
    else{
      header('Location:adminregistrationlist.php');
    }
}

?>

<style>
  .required{
    color: red;
    font-weight:bold;
  }

</style>

<div class="container">
  <br><br>
  <h1 style="text-align: center;"><b>Registration Detail</b></h1>

      <div class="card mb-3 col-10 my-5 mx-auto">
      <div class="card-header text-white bg-primary d-flex justify-content-between align-items-center">
        Registration Detail
        <button type="button" class="btn btn-secondary"  onclick="window.location.href='adminregistrationlist.php'">
            Back
        </button> 
      </div>
      <div class="card-body">
        <table class="table table-hover">
          <tbody>
            <tr>
              <td scope="row">Registration ID</td>
              <td><?= $row['r_tid']; ?></td>
            </tr>
            <tr>
              <td scope="row">Student ID</td>
              <td><?= $row['r_student']; ?></td>
            </tr>
            <tr>
              <td scope="row">Student Name</td>
              <td><?= $row['u_name']; ?></td>
            </tr>
            <tr>
              <td scope="row">Course Code</td>
              <td><?= $row['r_course']; ?></td>
            </tr>
            <tr>
              <td scope="row">Course Name</td>
              <td><?= $row['c_name']; ?></td>
            </tr>
            <tr>
              <td scope="row">Section</td>
              <td><?= $row['r_section']; ?></td>
            </tr>
            <tr>
              <td scope="row">Semester</td>
              <td><?= $row['r_sem']; ?></td>
            </tr>
            <tr>
              <td scope="row">Status</td>
              <td><?= $row['status']; ?></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="card mb-3 col-10 my-5 mx-auto">
    <div class="card-header text-white bg-primary d-flex justify-content-between align-items-center">
        Amendment
    </div>
    <div class="card-body">
        <form method="post">
            <div class="form-group">
                <label for="r_section">Section <span class="required">*</span></label>
                <select class="form-control" name="r_section" id="r_section" required>
                <?php
                    $course_code=$row['r_course'];
                    $sections_query="SELECT c_section 
                                     FROM tb_course 
                                     WHERE c_code='$course_code'";
                    $sections_result=mysqli_query($con, $sections_query);

                    while ($section=mysqli_fetch_assoc($sections_result)){
                        $selected=$section['c_section'] == $row['r_section'] ? 'selected' : '';
                        echo "<option value='" . $section['c_section'] . "' $selected>" . $section['c_section'] . "</option>";
                    }
                ?>
                </select>
            </div>
            <br>
            <div class="d-flex justify-content-center">
                <button type="button" class="btn btn-secondary me-3" onclick="window.location.href='adminregistrationlist.php'">Back</button>
                <button onclick="return confirmation(event);" class="btn btn-primary">Amend</button>
            </div>
        </form>
    </div>
</div>

<br><br><br><br>

<script>
  function confirmation(event) {
    event.preventDefault(); 
    const fields = document.querySelectorAll("[required]");

    for (let field of fields) {
      if (field.value.trim() === "") {
        Swal.fire({
          icon: 'error',
          title: 'Required field not filled!',
          text: 'Please fill all required fields.',
        });
        event.preventDefault();
        return false;
      }
    }

    event.preventDefault();

            Swal.fire({
                title: 'Are you sure?',
                text: 'Registration will be amended!',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Yes',
                cancelButtonText: 'No'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Registration is amended!',
                        showConfirmButton: true
                    }).then(() => {
                        document.querySelector('form').submit();
                    });
                } else {
                    Swal.fire({
                        icon: 'info',
                        title: 'Registration is not amended',
                    }).then(() => {
                        window.location.href='adminregistrationlist.php';
                    });
                }
            });
        }
</script>





  
</div>
<?php include 'footer.php';?>