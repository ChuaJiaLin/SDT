<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}

if ($_SESSION['u_type']!=3) { 
    header('Location:login.php');
    exit();
}

include 'headeradmin.php';
include 'dbconnect.php';

if ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['add_course'])) {
    $c_code=$_POST['c_code'];
    $c_name=$_POST['c_name'];
    $c_section=$_POST['c_section'];
    $c_sem=$_POST['c_sem'];
    $c_credit=substr($c_code,-1);
    $c_lec=$_POST['c_lec'];
    $c_studNum=$_POST['c_studNum'];

    $sql="INSERT INTO tb_course (c_code,c_name,c_section,c_sem,c_credit,c_lec,c_studNum) 
          VALUES ('$c_code','$c_name','$c_section','$c_sem','$c_credit','$c_lec','$c_studNum')";
    mysqli_query($con,$sql);
    header('Location: admincourselist.php');
    exit();
}

$lecturers_query="SELECT u_sno,u_name
                  FROM tb_user 
                  WHERE u_type='1'";

$lecturers_result=mysqli_query($con,$lecturers_query);

?>

<style>
  table thead th{
      text-align: center;
      background-color: #f1f1f1;
  }

  table tbody td{
      text-align: center;
  }

  .required{
    color: red;
    font-weight:bold;
  }
</style>

<div class="container">
    <br><br>
    <h1 style="text-align: center;"><b>Add Course</b></h1><br>

    <br>

    <form method="POST" class="form-inline">
        <div class="form-group">
          <label for="search_code">Course Code <span class="required">*</span></label>
          <input type="text" name="c_code" class="form-control" placeholder="Course Code" required>
          <br>
          <label for="search_code">Course Name <span class="required">*</span></label>
          <input type="text" name="c_name" class="form-control" placeholder="Course Name" required>
          <br>
          <label for="search_code">Course Section <span class="required">*</span></label>
          <input type="text" name="c_section" class="form-control" placeholder="Section" required>
          <br>
          <label for="search_code">Course Semester <span class="required">*</span></label>
          <select name="c_sem" class="form-control" required>
            <option value="">Select Semester</option>
            <option>2024/2025-1</option>
            <option>2024/2025-2</option>
            <option>2024/2025-3</option>
          </select>
          <br>
          <label for="search_code">Course Lecturer <span class="required">*</span></label>
          <select name="c_lec" class="form-control" required>
            <option value="">Select Lecturer</option>
            <?php
            while ($lecturer = mysqli_fetch_assoc($lecturers_result)) {
                echo "<option value='" . $lecturer['u_sno'] . "'>" . $lecturer['u_name'] . "</option>";
            }
            ?>
          </select>
          <br>
          <label for="search_code">Course Capacity <span class="required">*</span></label>
          <input type="text" name="c_studNum" class="form-control" placeholder="Capacity" required>
        </div>
        <br>
        <div class="d-flex justify-content-center">
            <a href="admincourselist.php">
                <button type="button" class="btn btn-info me-3">Back</button>
            </a>
            <button type="button" onclick=" confirmation(event);" class="btn btn-success">Add Course</button>
        </div>
    </form>
    <br><br>
    
</div>
<br><br><br><br>

<script>
    function confirmation(event){
            const fields = document.querySelectorAll("[required]");
            for (let field of fields) {
                if (field.value.trim() === ""){
                    Swal.fire({
                        icon: 'error',
                        title: 'Required field not filled!',
                        text: 'Please fill all required fields.',
                    });
                    event.preventDefault();
                    return false;
                }
            }

            Swal.fire({
                title: 'Are you sure?',
                text: 'New course will be added.',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Yes',
                cancelButtonText: 'No'
            }).then((result) => {
                if (result.isConfirmed){
                    Swal.fire({
                        icon: 'success',
                        title: 'New course is added!',
                        showConfirmButton: true
                    }).then(() => {
                        const form=document.querySelector('form');
                        const addCourseField=document.createElement('input');
                        addCourseField.type='hidden';
                        addCourseField.name='add_course';
                        addCourseField.value='1';
                        form.appendChild(addCourseField);
                        form.submit();
                    });
                } else {
                    Swal.fire({
                        icon: 'info',
                        title: 'No course is added!',
                    }).then(() => {
                        window.location.href='admincourselist.php';
                    });
                }
            });
        }
</script>

<?php include 'footer.php'; ?>
