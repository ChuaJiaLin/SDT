<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}

if ($_SESSION['u_type']!= 2) { 
    header('Location: login.php');
    exit();
}

// Connect to DB
include('headerstudent.php');
include('dbconnect.php');

// Retrieve data from form
$uic=$_SESSION['funame']; 
$fcourse=$_POST['fcourse'];
$fsection=$_POST['fsection'];
$fsem=$_POST['fsem'];

$check_sql="SELECT * 
            FROM tb_registration 
            WHERE r_student='$uic' AND r_course='$fcourse' AND r_sem='$fsem' AND r_section='$fsection'";

$result=mysqli_query($con, $check_sql);

if (mysqli_num_rows($result)>0){
    echo "<script>
            Swal.fire({
                icon: 'error',
                title: 'Registration Exists',
                text: 'You have already registered for this course in this semester and section.',
                confirmButtonText: 'OK'
            }).then(() => {
                window.location.href = 'courseregister.php';
            });
          </script>";
          exit;
} 
/*else{
    $sql = "INSERT INTO tb_registration (r_student,r_course,r_sem,r_section,r_status)
            VALUES ('$uic','$fcourse','$fsem','$fsection','1')";

    if (mysqli_query($con, $sql)){
        echo "<script>
                Swal.fire({
                    icon: 'success',
                    title: 'Registration Successful',
                    text: 'You have successfully registered for the course.',
                    confirmButtonText: 'OK'
                }).then(() => {
                    window.location.href = 'courseview.php';
                });
              </script>";
        exit;
    } 
    else{
        echo "<script>
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'There was an issue registering your course. Please try again later.',
                    confirmButtonText: 'OK'
                }).then(() => {
                    window.location.href = 'courseregister.php';
                });
              </script>";
        exit;
    }
}*/

$capacity_sql="SELECT c_studNum, 
               (SELECT COUNT(*) 
               FROM tb_registration 
               WHERE r_course='$fcourse' 
               AND r_section='$fsection' 
               AND r_sem='$fsem' 
               AND r_status='2') AS approved_count 
               FROM tb_course 
               WHERE c_code = '$fcourse' 
               AND c_section = '$fsection'";

$capacity_result=mysqli_query($con,$capacity_sql);
if ($capacity_result && mysqli_num_rows($capacity_result)>0) {
    $row=mysqli_fetch_assoc($capacity_result);
    $course_capacity=$row['c_studNum'];
    $approved_count=$row['approved_count'];

    $status=($approved_count < $course_capacity) ? 2 : 1; 

    $sql="INSERT INTO tb_registration (r_student,r_course,r_sem, r_section,r_status)
          VALUES ('$uic','$fcourse','$fsem','$fsection','$status')";

    if (mysqli_query($con,$sql)) {
        $status_message=($status==2) ? 'Registration Approved' : 'Registration Pending Approval';
        echo "<script>
                Swal.fire({
                    icon: 'success',
                    title: '$status_message',
                    text: 'You have successfully registered for the course.',
                    confirmButtonText: 'OK'
                }).then(() => {
                    window.location.href = 'courseview.php';
                });
              </script>";
        exit;
    } else {
        echo "<script>
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'There was an issue registering your course. Please try again later.',
                    confirmButtonText: 'OK'
                }).then(() => {
                    window.location.href = 'courseregister.php';
                });
              </script>";
        exit;
    }
} else {
    echo "<script>
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Unable to retrieve course capacity. Please try again later.',
                confirmButtonText: 'OK'
            }).then(() => {
                window.location.href = 'courseregister.php';
            });
          </script>";
    exit;
}


mysqli_close($con);
?>
