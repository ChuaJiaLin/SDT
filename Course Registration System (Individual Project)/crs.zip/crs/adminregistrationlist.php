<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}

if ($_SESSION['u_type']!=3) { 
    header('Location:login.php');
    exit();
}

include 'headeradmin.php';
include 'dbconnect.php';

$status_filter=$_GET['status'] ?? '';

$where_clauses=[];

if (!empty($status_filter)){
    $where_clauses[]="tb_registration.r_status='$status_filter'";
}

$where_sql=!empty($where_clauses) ? "WHERE " . implode(' AND ',$where_clauses) : '';

$records_per_page=10;

$current_page=isset($_GET['page']) ? (int)$_GET['page']:1;

$offset=($current_page-1)*$records_per_page;

$count_sql="SELECT COUNT(*) AS total 
            FROM tb_course";

$count_result=mysqli_query($con,$count_sql);
$total_records=mysqli_fetch_assoc($count_result)['total'];

$total_pages=ceil($total_records/$records_per_page);

$sql = "SELECT DISTINCT tb_registration.*,
               tb_user.u_name, 
               tb_course.c_name,
               tb_status.s_decs AS status
        FROM tb_registration 
        LEFT JOIN tb_user ON tb_registration.r_student=tb_user.u_sno
        LEFT JOIN tb_course ON tb_registration.r_course=tb_course.c_code
        LEFT JOIN tb_status ON tb_registration.r_status=tb_status.s_id
        $where_sql
        LIMIT $records_per_page OFFSET $offset";

$result=mysqli_query($con,$sql);

if (isset($_GET['delete_id'])){
    $delete_id=$_GET['delete_id'];
    $delete_query="DELETE FROM tb_registration 
                   WHERE r_tid='$delete_id'";
    mysqli_query($con,$delete_query);
    header('Location: adminregistrationlist.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_status'])) {
    $registration_id = $_POST['registration_id'];
    $new_status = $_POST['new_status'];

    // Fetch course details related to the registration
    $course_query = "SELECT tb_course.c_studNum, tb_registration.r_course 
                     FROM tb_registration 
                     INNER JOIN tb_course ON tb_registration.r_course = tb_course.c_code 
                     WHERE tb_registration.r_tid = '$registration_id'";
    $course_result = mysqli_query($con, $course_query);
    $course_data = mysqli_fetch_assoc($course_result);

    if ($new_status == '2') { // Only validate if status is being changed to "Approved"
        $course_code = $course_data['r_course'];
        $max_students = $course_data['c_studNum'];

        // Count approved students for the same course
        $approved_count_query = "SELECT COUNT(*) AS approved_count 
                                 FROM tb_registration 
                                 WHERE r_course = '$course_code' AND r_status = '2'";
        $approved_count_result = mysqli_query($con, $approved_count_query);
        $approved_count = mysqli_fetch_assoc($approved_count_result)['approved_count'];

        // Prevent approval if approved students reach the maximum limit
        if ($approved_count >= $max_students) {
            echo "<script>
              Swal.fire({
                    icon: 'error',
                    title: 'Approval Failed',
                    text: 'Cannot approve registration. Maximum number of students for this course has been reached.',
                });
                </script>";
        } else {
            // Proceed with the update
            $update_query = "UPDATE tb_registration 
                             SET r_status = '$new_status' 
                             WHERE r_tid = '$registration_id'";
            if (mysqli_query($con, $update_query)) {
                echo "<script>
                      Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: 'Status updated successfully!',
                    }).then(() => {
                        window.location.href = 'adminregistrationlist.php';
                    });</script>";
            } else {
                echo "<script>
                      Swal.fire({
                        icon: 'error',
                        title: 'Update Failed',
                        text: 'Failed to update status.',
                    });
                    </script>";
            }
        }
    } else {
        // Update directly for other status changes
        $update_query = "UPDATE tb_registration 
                         SET r_status = '$new_status' 
                         WHERE r_tid = '$registration_id'";
        if (mysqli_query($con, $update_query)) {
            echo "<script>
              Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: 'Status updated successfully!',
                }).then(() => {
                    window.location.href = 'adminregistrationlist.php';
                });
                </script>";
        } else {
            echo "<script>
              Swal.fire({
                    icon: 'error',
                    title: 'Update Failed',
                    text: 'Failed to update status.',
                });
                </script>";
        }
    }
}
?>

<style>
  table thead th{
      text-align: center;
      background-color: #f1f1f1;
  }

  table tbody td{
      text-align: center;
  }
</style>

<div class="container">
    <br><br>
    <h1 style="text-align: center;"><b>Manage Registration</b></h1><br>

    <form method="GET" action="" class="mb-3 d-flex justify-content-center">
        <select name="status" class="form-select me-2" style="width: 200px;">
            <option value="">-- All Status --</option>
            <?php
            $status_query="SELECT * FROM tb_status WHERE s_id";
            $status_result=mysqli_query($con,$status_query);
            while ($status=mysqli_fetch_assoc($status_result)){
                $selected=(isset($_GET['filter_status']) && $_GET['filter_status']==$status['s_id']) ? 'selected' : '';
                echo "<option value='{$status['s_id']}' $selected>{$status['s_decs']}</option>";
            }
            ?>
        </select>
        <button type="submit" class="btn btn-primary">Tapis</button>
    </form>

    <br>

    <table class="table table-hover">
      <thead>
        <tr>
          <th scope="col">Registration ID</th>
          <th scope="col">Student ID</th>
          <th scope="col">Student Name</th>
          <th scope="col">Course Code</th>
          <th scope="col">Course Name</th>
          <th scope="col">Section</th>
          <th scope="col">Semester</th>
          <th scope="col">Status</th>
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row=mysqli_fetch_array($result)) { ?>
        <tr>
          <td><?php echo $row['r_tid']; ?></td>
          <td><?php echo $row['r_student']; ?></td>
          <td><?php echo $row['u_name']; ?></td>
          <td><?php echo $row['r_course']; ?></td>
          <td><?php echo $row['c_name']; ?></td>
          <td><?php echo $row['r_section']; ?></td>
          <td><?php echo $row['r_sem']; ?></td>
          <td>
            <!-- <form method="POST" onchange="event.preventDefault(); edit_status(this);"> -->
              <form method="POST">
              <select class="form-control" name="new_status" required onchange="this.form.submit()">
                <option value="1" <?= $row['r_status'] == '1' ? 'selected' : ''; ?>>Received</option>
                <option value="2" <?= $row['r_status'] == '2' ? 'selected' : ''; ?>>Approved</option>
                <option value="3" <?= $row['r_status'] == '3' ? 'selected' : ''; ?>>Rejected</option>
                <option value="4" <?= $row['r_status'] == '4' ? 'selected' : ''; ?>>Amended</option>
              </select>
              <input type="hidden" name="registration_id" value="<?= $row['r_tid']; ?>">
              <input type="hidden" name="edit_status" value="1">
            </form>
          </td>
          <td>
            <?php
              echo "<a href='adminregistrationdetail.php?r_tid=" . $row['r_tid'] . "'><button type='submit' class='btn btn-info me-3'>Detail</button></a>";
              echo "<button class='btn btn-danger me-3' onclick=\"delete_registration(" . $row['r_tid'] . ")\">Delete</button>";
            ?>
          </td>
        </tr>
        <?php } ?>
        </tbody>
    </table>
</div>

<nav>
  <ul class="pagination justify-content-center">
    <?php if ($current_page>1): ?>
    <li class="page-item">
      <a class="page-link" href="?page=<?= $current_page-1; ?>">&laquo;</a>
    </li>
    <?php endif; ?>

    <?php for ($i=1;$i<=$total_pages;$i++): ?>
    <li class="page-item <?= ($i==$current_page) ? 'active' : ''; ?>">
      <a class="page-link" href="?page=<?= $i; ?>"><?= $i; ?></a>
    </li>
    <?php endfor; ?>

    <?php if ($current_page<$total_pages): ?>
    <li class="page-item">
      <a class="page-link" href="?page=<?= $current_page+1; ?>">&raquo;</a>
    </li>
    <?php endif; ?>
  </ul>
</nav>

<br><br><br><br>

<script>
  /*function edit_status(form){
    const registrationId=form.registration_id.value;
    const newStatus=form.new_status.value;

    Swal.fire({
      title: 'Are you sure?',
      text: `Status for registration ID: ${registrationId} will change to ${newStatus === '1' ? 'Received' : newStatus === '2' ? 'Approved' : 'Rejected'}.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
    }).then((result) => {
      if (result.isConfirmed){
        form.submit();
      } 
      else{
        Swal.fire({
          icon: 'info',
          title: 'Status not changed.',
        });
      }
    });
  }*/

  function delete_registration(delete_id){
    Swal.fire({
      title: 'Are you sure?',
      text: 'This registration will be deleted.',
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.isConfirmed){
        Swal.fire({
          icon: 'success',
          title: 'Registration is deleted!',
          showConfirmButton: true
        }).then(() => {
          window.location.href=`adminregistrationlist.php?delete_id=${delete_id}`;
        });
      } 
      else {
        Swal.fire({
          icon: 'info',
          title: 'Registration is not deleted!',
        }).then(() => {
          window.location.href='adminregistrationlist.php';
        });
      }
    });
  }
</script>
<?php include 'footer.php'; ?>
