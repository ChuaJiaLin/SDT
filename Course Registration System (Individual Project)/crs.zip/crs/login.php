<?php include 'headermain.php';?>
<div class="container">

  <br><br><h5>Please fill to login</h5>
  <form method="POST" action="loginprocess.php">
  <fieldset>
 
    <div>
      <label for="exampleInputEmail1" class="form-label mt-4">Enter your staff or student ID</label>
      <input type="text"  name="funame" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your staff or student ID" required>
    </div>

    <div>
      <label for="exampleInputPassword1" class="form-label mt-4">Enter password</label>
      <input type="password" name="fpwd" class="form-control" id="exampleInputPassword1" placeholder="Create your password" autocomplete="off" required>
    </div>

    <br>
    <div class="d-flex justify-content-center">
      <button type="submit" class="btn btn-primary">Login</button>
    </div>
   </fieldset>

</form>
<br><br><br>
</div>

<?php include 'footer.php';?>