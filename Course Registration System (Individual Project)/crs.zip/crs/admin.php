<?php 

include('crssession.php');
if(!session_id())
{
  session_start();
}

if ($_SESSION['u_type']!=3) { 
    header('Location: login.php');
    exit();
}

if(isset($_SESSION['u_sno']) != session_id())
{
  header('Location:login.php'); 
}

include 'headeradmin.php';
?>
<div class="container">
  IT Staff Page

</div>
<?php include 'footer.php';?>