<?php include 'headermain.php';?>
<div class="container">

<style>
  .required{
    color: red;
    font-weight:bold;
  }

</style>

  <br><br><h5>Please fill in all following details</h5>
  <form method="POST" action="registerprocess.php">
  <fieldset>
 
    <div>
      <label for="exampleInputEmail1" class="form-label mt-4">Please enter your staff or student ID<span class="required"> *</span></label>
      <input type="text"  name="funame" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your staff or student ID" required>
    </div>

    <div>
      <label for="exampleSelect1" class="form-label mt-4">Select role<span class="required"> *</span></label>
      <select class="form-select" name="fusertype" id="exampleSelect1" required>
        <option value="1">Lecturer</option>
        <option value="2">Student</option>
        <option value="3">IT Staff</option>
      </select>
    </div>

    <div>
      <label for="exampleInputPassword1" class="form-label mt-4">Create your password<span class="required"> *</span></label>
      <input type="password" name="fpwd" class="form-control" id="exampleInputPassword1" placeholder="Create your password" autocomplete="off" required>
    </div>

    <div>
      <label for="exampleInputPassword1" class="form-label mt-4">Confirm your password<span class="required"> *</span></label>
      <input type="password" name="fpwd1" class="form-control" id="exampleInputPassword1" placeholder="Create your password" autocomplete="off" required>
    </div>

    <div>
      <label for="exampleInputEmail1" class="form-label mt-4">Please enter your email<span class="required"> *</span></label>
      <input type="email" name="femail" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your email" required>
    </div>

    <div>
      <label for="exampleInputEmail1" class="form-label mt-4">Please enter your full name<span class="required"> *</span></label>
      <input type="text"  name="fname" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your full name" required>
    </div>

    <div>
      <label for="exampleInputEmail1" class="form-label mt-4">Please enter your contact number<span class="required"> *</span></label>
      <input type="text"  name="fcontact" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your mobile or fixed line number"required>
    </div>

    <div>
      <label for="exampleSelect1" class="form-label mt-4">Select your state<span class="required"> *</span></label>
      <select class="form-select" name="fstate" id="exampleSelect1" required>
        <option>Johor</option>
        <option>Kedah</option>
        <option>Kelantan</option>
        <option>Melaka</option>
        <option>Negeri Sembilan</option>
        <option>Pahang</option>
        <option>Pulau Pinang</option>
        <option>Perak</option>
        <option>Perlis</option>
        <option>Sabah</option>
        <option>Sarawak</option>
        <option>Selangor</option>
        <option>Terengganu</option>
        <option>W.P. Kuala Lumpur</option>
        <option>W.P. Labuan</option>
        <option>W.P. Putrajaya</option>
      </select>
    </div>

    <br>
    <div class="d-flex justify-content-center">
      <button type="submit" class="btn btn-primary me-3">Submit</button>
      <button type="reset" class="btn btn-warning">Reset</button>
    </div>
   </fieldset>

</form>
<br><br><br>
</div>

<?php include 'footer.php';?>