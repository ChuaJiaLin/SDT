<?php
include('crssession.php');
if(!session_id())
{
  session_start();
}

if ($_SESSION['u_type']!=1) { 
    header('Location:login.php');
    exit();
}

include 'headerlect.php';
include 'dbconnect.php';
$uic=$_SESSION['funame'];

if (isset($_GET['c_id']) && !empty($_GET['c_id']) && is_numeric($_GET['c_id'])){
  $c_id=intval($_GET['c_id']);
} 
else{
  die("<div class='container'><h4 style='text-align: center;'>Invalid course ID.</h4></div>");
}

$sql="SELECT * FROM tb_course
      LEFT JOIN tb_user ON tb_course.c_lec = tb_user.u_sno
      WHERE c_id=$c_id";

$result=mysqli_query($con,$sql);

if (!$result||mysqli_num_rows($result)==0){
    die("<div class='container'><h4 style='text-align: center;'>No course details found.</h4></div>");
}

$row=mysqli_fetch_assoc($result);

?>

<div class="container">
  <br><br>
  <h1 style="text-align: center;"><b>Course Detail</b></h1>

      <div class="card mb-3 col-10 my-5 mx-auto">
      <div class="card-header text-white bg-primary d-flex justify-content-between align-items-center">
        Course Detail
        <button type="button" class="btn btn-secondary"  onclick="window.location.href='lectcourselist.php'">
            Back
        </button> 
      </div>
      <div class="card-body">
        <table class="table table-hover">
          <tbody>
            <tr>
              <td scope="row">ID</td>
              <td><?= $row['c_id']; ?></td>
            </tr>
            <tr>
              <td scope="row">Code</td>
              <td><?= $row['c_code']; ?></td>
            </tr>
            <tr>
              <td scope="row">Name</td>
              <td><?= $row['c_name']; ?></td>
            </tr>
            <tr>
              <td scope="row">Credit</td>
              <td><?= $row['c_credit']; ?></td>
            </tr>
            <tr>
              <td scope="row">Semester</td>
              <td><?= $row['c_sem']; ?></td>
            </tr>
            <tr>
              <td scope="row">Section</td>
              <td><?= $row['c_section']; ?></td>
            </tr>
            <tr>
              <td scope="row">Lecturer ID</td>
              <td><?= $row['c_lec']; ?></td>
            </tr>
            <tr>
              <td scope="row">Lecturer Name</td>
              <td><?= $row['u_name']; ?></td>
            </tr>
            <tr>
              <td scope="row">Number of Student</td>
              <td><?= $row['c_studNum']; ?></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <br><br><br><br>







  
</div>
<?php include 'footer.php';?>