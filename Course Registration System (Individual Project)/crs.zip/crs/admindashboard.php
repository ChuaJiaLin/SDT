<?php
include('crssession.php');
include('dbconnect.php');

if ($_SESSION['u_type']!=3) { 
    header('Location:login.php');
    exit();
}

$student_count="SELECT COUNT(*) AS total 
                FROM tb_user
                WHERE u_type='2'";

$course_count="SELECT COUNT(DISTINCT c_code) AS total FROM tb_course";

$registration_count="SELECT COUNT(*) AS total FROM tb_registration";

$pending_registration_count="SELECT COUNT(*) AS total 
                             FROM tb_registration 
                             WHERE r_status=1";

$approved_registration_count="SELECT COUNT(*) AS total 
                             FROM tb_registration 
                             WHERE r_status=2";

$rejected_registration_count="SELECT COUNT(*) AS total 
                             FROM tb_registration 
                             WHERE r_status=3";

$amended_registration_count="SELECT COUNT(*) AS total 
                             FROM tb_registration 
                             WHERE r_status=4";

$total_students=mysqli_fetch_assoc(mysqli_query($con,$student_count))['total'];

$total_courses=mysqli_fetch_assoc(mysqli_query($con,$course_count))['total'];

$total_registrations=mysqli_fetch_assoc(mysqli_query($con,$registration_count))['total'];

$pending_registrations=mysqli_fetch_assoc(mysqli_query($con,$pending_registration_count))['total'];

$approved_registrations=mysqli_fetch_assoc(mysqli_query($con,$approved_registration_count))['total'];

$rejected_registrations=mysqli_fetch_assoc(mysqli_query($con,$rejected_registration_count))['total'];

$amended_registrations=mysqli_fetch_assoc(mysqli_query($con,$amended_registration_count))['total'];

$status_query = "
    SELECT r_status, COUNT(*) AS total 
    FROM tb_registration 
    GROUP BY r_status";
$status_result = mysqli_query($con, $status_query);

$status_data = [0, 0, 0, 0]; // Pending, Approved, Rejected, Amended
while ($row = mysqli_fetch_assoc($status_result)) {
    $status_data[$row['r_status'] - 1] = $row['total'];
}

// Fetch registrations per course
$course_query = "
    SELECT tb_course.c_name, COUNT(tb_registration.r_tid) AS total 
    FROM tb_registration
    INNER JOIN tb_course ON tb_registration.r_course = tb_course.c_code
    GROUP BY tb_course.c_name";
$course_result = mysqli_query($con, $course_query);

$course_labels = [];
$course_data = [];
while ($row = mysqli_fetch_assoc($course_result)) {
    $course_labels[] = $row['c_name'];
    $course_data[] = $row['total'];
}


?>

<body>
    <?php include 'headeradmin.php'; ?>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Dashboard</h1>
        
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card text-center bg-primary text-white">
                    <div class="card-body" title="Total number of students registered in this system">
                        <h5>Total Students</h5>
                        <h3><?= $total_students; ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center bg-success text-white">
                    <div class="card-body" title="Total number of courses in this system">
                        <h5>Total Courses</h5>
                        <h3><?= $total_courses; ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center bg-info text-white">
                    <div class="card-body" title="Total number of registrations made by students">
                        <h5>Total Registrations</h5>
                        <h3><?= $total_registrations; ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center bg-warning text-white">
                    <div class="card-body" title="Total number of pending registrations">
                        <h5>Pending Registrations</h5>
                        <h3><?= $pending_registrations; ?></h3>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col d-flex justify-content-center align-items-center">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Registration Status</h5>
                        <canvas id="registrationChart" style="width: 400px; height: 400px; margin:auto;"></canvas>
                        <script>
                            const registrationStatusData=[<?= $pending_registrations; ?>,<?= $approved_registrations; ?>,<?= $rejected_registrations; ?>,<?= $amended_registrations; ?>];
                            const registrationStatusLabels = ['Pending','Approved','Rejected','Amended'];

                            const ctx1 = document.getElementById('registrationChart').getContext('2d');
                            new Chart(ctx1, {
                                type: 'pie',
                                data: {
                                    labels: registrationStatusLabels,
                                    datasets: [{
                                        data: registrationStatusData,
                                        backgroundColor: ['#FFC107', '#28A745', '#DC3545', '#17A2B8']
                                    }]
                                }
                            });
                        </script>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-5">
            <div class="col-md-4">
                <a href="admincourselist.php" class="btn btn-outline-primary w-100">Manage Courses</a>
            </div>
            <div class="col-md-4">
                <a href="addcourse.php" class="btn btn-outline-success w-100">Add Course</a>
            </div>
            <div class="col-md-4">
                <a href="adminregistrationlist.php" class="btn btn-outline-info w-100">Manage Registration</a>
            </div>
            <div class="col-md-4">
                <a href="modifypassword.php" class="btn btn-outline-primary w-100">Modify Password</a>
            </div>
        </div>
    </div>
    <br><br><br><br>

</body>
</html>
